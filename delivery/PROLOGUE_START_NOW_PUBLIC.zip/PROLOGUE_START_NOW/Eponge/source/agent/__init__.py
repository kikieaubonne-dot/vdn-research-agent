"""VDN research agent."""

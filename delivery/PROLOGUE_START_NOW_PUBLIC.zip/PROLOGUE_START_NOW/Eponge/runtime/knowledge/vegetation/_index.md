# Index — vegetation

Classement : statut, puis confiance, puis niveau de la source (1 = doc officielle). Les fiches rejetées sont en bas, gardées pour l'historique.

## Documenté (4)

- [[vegetation/5bbf6043ed9c-class-surfaceappearance|Class: SurfaceAppearance]] — niv. 1 · conf. moyenne — « set of **Physically‑Based Rendering** (PBR) texture images, or maps, on a »
- [[spruce/416e116697cfeae6caad-foliage-using-surfaceappearance-become-highly|Foliage Using SurfaceAppearance Become Highly Transparent at Distance in Roblox Player (Graphics +9) but Renders Correctly in Studio]] — niv. 2 · conf. faible
- [[spruce/c20177c2856493a2bece-surfaceappearance-alphamode-transparency-rend|SurfaceAppearance AlphaMode.Transparency renders in bands on opaque MeshParts]] — niv. 2 · conf. faible
- [[spruce/7de7a1a415ccdf51b0fe-texture-atlases-creating-foliage-texture-and-|Texture Atlases - Creating Foliage Texture and Meshes]] — niv. 2 · conf. faible

## Candidat (2)

- [[vegetation/d5dda0d02f6d-manage-level-of-detail-settings-on-roblox|Manage level of detail settings on Roblox]] — niv. 1 · conf. faible — « ## Manage level of detail settings on Roblox: Introduction to LOD ([0:00](https://www.youtube.com/watch?v=Wwj8EkMWFhI&t=0s)) »
- [[spruce/4b3e4c63ddab358ee1df-nightcycle-quick-part|nightcycle/quick-part]] — niv. 3 · conf. faible

## Rejetées / obsolètes (4)

- [[spruce/030e47b1915a4bee4fae-diyorfayz-skills|DiyorFayz/skills]] — hors sujet (pertinence 0.167 < 0.5); bruit : titre : « skills »
- [[spruce/b5b20f5a22d418ff7394-gnrpflpferd19-skapidap|Gnrpflpferd19/skapidap]] — hors sujet (pertinence 0.267 < 0.5)
- [[spruce/0aaa704c0c2d9a1b94c5-sigmalordmaster69-super-smart-idea-im-about-t|SigmaLordMaster69/super-smart-idea-im-about-to-have]] — hors sujet (pertinence 0.267 < 0.5)
- [[spruce/4c4e9e4faa27af447c21-scenario-labs-skills|scenario-labs/skills]] — hors sujet (pertinence 0.167 < 0.5); bruit : titre : « skills »

